<?php
$firstname = filter_input(INPUT_POST, 'firstname');
$lastname = filter_input(INPUT_POST, 'lastname');
$phone = filter_input(INPUT_POST, 'phone');
$email = filter_input(INPUT_POST, 'email');
$country = filter_input(INPUT_POST, 'country');
$subject = filter_input(INPUT_POST, 'subject');

if(!empty($firstname) || !empty($lastname) || !empty($phone) || !empty($email) || !empty($country) || !empty($subject)) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "root";
    $dbname = "contacts"

    //create connection
    $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);

    if (new mysqli_connect_error()){
        die("Connect Error(". mysqli_connect_error().')'. mysqli_connect_error());
    } else {
        $SELECT = "SELECT email From contact Where email = ? Limit 1";
        $INSERT = "INSERT Into contact (firstname, lastname, phone, email, country, subject) values(?, ?, ?, ?, ?, ?)";

         //prepare statement
         $stmt = $conn->prepare($SELECT);
         $stmt->bind_param("s",$email);
         $stmt->execute();
         $stmt->bind_result($email);
         $stmt->store_result();
         $rnum = $stmt->num_rows;

         if ($num==0) {
             $stmt->close();

             $stmt = $conn->prepare($INSERT);
             $stmt->bind_param("ssssii", $firstname, $lastname, $phone, $email, $country, $subject);
             echo "New record inserted successfully";
         } els {
             echo "Someone already registered using this email"; 
          }
          $stmt->close();
          $stmt->close();

} else {
     echo "All fields are required";
     die();
}

?>